var data = [{"name":"dd","value":6}, 
{"name":"dt","value":6}, 
{"name":"dl","value":6}, 
{"name":"fieldset","value":7}, 
{"name":"base","value":7}, 
{"name":"i","value":8}, 
{"name":"h5","value":8}, 
{"name":"iframe","value":10}, 
{"name":"center","value":10}, 
{"name":"font","value":12}, 
{"name":"embed","value":12}, 
{"name":"tbody","value":13}, 
{"name":"area","value":14}, 
{"name":"map","value":14}, 
{"name":"hr","value":14}, 
{"name":"param","value":16}, 
{"name":"object","value":16}, 
{"name":"b","value":17}, 
{"name":"br","value":19}, 
{"name":"h4","value":20}, 
{"name":"em","value":21}, 
{"name":"option","value":24}, 
{"name":"select","value":24}, 
{"name":"label","value":28}, 
{"name":"noscript","value":31}, 
{"name":"h3","value":38}, 
{"name":"strong","value":44}, 
{"name":"h1","value":45}, 
{"name":"tr","value":46}, 
{"name":"td","value":46}, 
{"name":"table","value":46}, 
{"name":"style","value":48}, 
{"name":"h2","value":48}, 
{"name":"span","value":79}, 
{"name":"br","value":82}, 
{"name":"ul","value":82}, 
{"name":"li","value":83}, 
{"name":"p","value":84}, 
{"name":"input","value":87}, 
{"name":"form","value":88}, 
{"name":"meta","value":93}, 
{"name":"link","value":93}, 
{"name":"script","value":96}, 
{"name":"img","value":96}, 
{"name":"div","value":97}, 
{"name":"a","value":97}, 
{"name":"html","value":98}, 
{"name":"title","value":99}, 
{"name":"body","value":99}, 
{"name":"head","value":99 }];

var width = 800,
    barHeight = 20;

var x = d3.scale.linear()
    .range([0, width]);

var chart = d3.select("#charthtml5commonelements")
    .attr("width", width);

/*d3.tsv("data.tsv", type, function(error, data) {
  x.domain([0, d3.max(data, function(d) { return d.value; })]);
*/
var data = data.reverse();

x.domain([0,d3.max(data,function(d){return d.value;})]);

  chart.attr("height", barHeight * data.length);

  var bar = chart.selectAll("g")
      .data(data)
      .enter().append("g")
      .attr("transform", function(d, i) { return "translate(0," + i * barHeight + ")"; });

  bar.append("rect")
      .attr("width", function(d) { return x(d.value); })
      .attr("height", barHeight - 1)
      .attr('class', function(d) { console.log(d); if (d.value > 60 ) { return 'highlight1' } else {return 'normal'} });

  bar.append("text")
      .attr("class","value")
      .attr("x", function(d) { return x(d.value) - 3; })
      .attr("y", barHeight / 2)
      .attr("dy", ".35em")
      .text(function(d) { return d.value; });

  bar.append("text")
      .attr("class","label")
      .attr("x", 3)
      .attr("y", barHeight / 2)
      .attr("dy", ".35em")
      .text(function(d) { return d.name; });


function type(d) {
  d.value = +d.value; // coerce to number
  return d;
}
