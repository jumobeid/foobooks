<!DOCTYPE html>
<html>

<head>
   <?php include("parts/htmlhead.php"); ?>
</head>

<body id="part1">
   <?php include("parts/nav.php"); ?>
    <div>
     <?php include("parts/content.php"); ?>
    </div>
    <div class="container" id="fcontainer">
            <?php include("parts/footer.php"); ?>
    </div>
    
</body>

</html>