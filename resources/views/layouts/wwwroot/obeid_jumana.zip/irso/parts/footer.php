       <footer id="footerimp">
            <div class="row">
                <div class="col-md-4 col-sm-6 footer-navigation">
                    
                    <p class="links"><a href="#">Home</a><strong> · </strong><a href="#">About </a><strong>  ·</strong><a href="#">Contact</a></p>
                    <p class="company-name">Insiights Co,© 2016</p>
                </div>
                <div class="col-md-4 col-sm-6 footer-contacts">
                    <div><span class="fa fa-map-marker footer-contacts-icon"> </span>
                        <p><span class="new-line-span">21 Revolution Street</span> Dubai, UAE</p>
                    </div>
                    <div><i class="fa fa-phone footer-contacts-icon"></i>
                        <p id="number" class="footer-center-info email text-left"> +971 50 6137078</p>
                    </div>
                    <div><i class="fa fa-envelope footer-contacts-icon"></i>
                        <p id="email">It@insightsrs.com</p>
                    </div>
                </div>
                <div class="clearfix visible-sm-block"></div>
                <div class="col-md-4 footer-about">
                   
                    <p> Lorem ipsum dolor sit amet, consectateur adispicing elit. Fusce euismod convallis velit, eu auctor lacus vehicula sit amet.
                    </p>
                    <div class="social-links social-icons"><a href="#"><i class="fa fa-facebook"></i></a><a href="#"><i class="fa fa-twitter"></i></a><a href="#"><i class="fa fa-linkedin"></i></a></div>
                </div>
            </div>
        </footer>