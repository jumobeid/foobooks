<!DOCTYPE html>
<html>

  <head>
    <title>Insights RealState</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
   
    <!-- Google fonts -->
    <link href='//fonts.googleapis.com/css?family=Habibi' rel='stylesheet'>

    <!-- font awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">
    
    <!--my customized stylesheet-->
    <link rel="stylesheet" href="assets/style1.css">
    <!-- favicon -->
    <link rel="shortcut icon" href="images/favicon1.ico" type="image/x-icon">
    <link rel="icon" href="images/favicon.ico" type="image/x-icon">
    <style>
        body{
            font-family: 'Habibi';
            margin: 0 auto;
            text-align: center;
            vertical-align: middle;
            margin-top: 250px;
        }
        p{
            font-family: 'Habibi';
            margin: 0 auto;
            font-weight:bold;
            font-size: 1.5em;
            color:#606161;
            
        }
      
    </style>
    

  </head>
  <body>
  
  
   <a href="index.php"><img src="http://insightsrs.com/assets/img/logo-450.png" alt="logo" id="logo"></a>
      <p>sorry page not found</p>
  </body>
  
  </html>