
    <div class="container">
        <div class="row">
            <div  class="col-md-12">
                <div id="cont">
               
                <h2>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum mollis ipsum a leo faucibus ullamcorper.</h2><p> Cras dapibus consequat leo ac condimentum. Maecenas eget semper nisl, eu hendrerit quam. Fusce nec orci vel quam ullamcorper congue.
                    Curabitur tellus dolor, facilisis at turpis a, placerat volutpat enim. Sed dapibus lobortis risus, semper ultrices purus lobortis vitae. Curabitur cursus dui eget velit accumsan, sollicitudin cursus felis mattis. Duis a elit interdum,
                    varius dolor tincidunt, tempus velit. Sed pulvinar, justo tincidunt tempus finibus, leo justo facilisis enim, ac volutpat purus enim eget sapien.   </p> </div><br/>
                <h2 id="gall">lorem porta tincidunt. Aliquam erat volutpat.Sed tincidunt nec diam cursus ullamcorper. </h2><br/></div></div>
        
   <div class="row">
        <div class="col-md-3">
            <a class="fancybox-thumbs thumbnail" data-fancybox-group="thumb" href="pic1.jpg"><img src="thumb/pic1.jpg" alt="" /></a></div>
        <div class="col-md-3">
            <a class="fancybox-thumbs thumbnail" data-fancybox-group="thumb" href="pic2.jpg"><img src="thumb/pic2.jpg" alt="" /></a></div>
        <div class="col-md-3">
            <a class="fancybox-thumbs thumbnail" data-fancybox-group="thumb" href="pic3.jpg"><img src="thumb/pic3.jpg" alt="" /></a></div>
        
        <div class="col-md-3">
		<a class="fancybox-thumbs thumbnail" data-fancybox-group="thumb" href="pic4.jpg"><img src="thumb/pic4.jpg" alt="" /></a></div>
        </div>
        

                   
        <br/>
    
                   <p>Vestibulum interdum, leo accumsan sollicitudin tincidunt, nunc metus euismod felis, nec
                    varius ipsum nibh a tortor. Aliquam erat volutpat. Pellentesque magna dui, varius at purus et, tempus luctus nibh. Sed euismod, leo vitae volutpat vulputate, velit nisi dictum mauris, eu hendrerit arcu ante et sem. In ac turpis libero.
                    Cras euismod metus non lorem porta tincidunt. Aliquam erat volutpat.Sed tincidunt nec diam cursus ullamcorper. Nulla congue hendrerit lacus. In at commodo dolor. Nulla quis nunc a sapien vulputate dignissim. Proin posuere facilisis
                    purus, nec lacinia purus facilisis et. Cras at odio mollis neque pulvinar efficitur eget lobortis tortor. Aenean ullamcorper finibus dui, ac ornare velit condimentum quis. Nulla aliquet, est id varius tempus, neque tellus scelerisque
                    purus, sit amet tristique massa erat vel risus. In placerat vestibulum magna et pulvinar. Nullam tempor dolor ac augue congue accumsan. Cras pulvinar, enim sit amet feugiat vehicula, nibh lectus luctus diam, quis pulvinar est ante
                    non lectus. Vivamus gravida ac purus in vulputate. Mauris tincidunt turpis orci, et dapibus ante pharetra vitae. Integer ullamcorper tempor lacus ac tempus.Aenean id urna facilisis, lobortis metus in, posuere nisi. Nullam porta velit
                       libero, in faucibus metus scelerisque vel. In vel lorem felis. Vestibulum luctus ligula aliquet, venenatis augue eget, accumsan elit. Mauris at nisi lectus. In laoreet dictum commodo.</p></div>
    <div id="pics" class="container">
        <div class="row">
            <div class="col-md-12">
                <h2 id="ourteam">Meet our Team</h2></div>
        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="thumbnail"><img src="assets/img/ppl1.jpg" alt="">
                    <div class="caption">
                        <h3>Thumbnail label</h3>
                        <p>Nullam id dolor id nibh ultricies vehicula ut id elit. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="thumbnail"><img src="assets/img/ppl2.jpg" alt="">
                    <div class="caption">
                        <h3>Thumbnail label</h3>
                        <p>Nullam id dolor id nibh ultricies vehicula ut id elit. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="thumbnail"><img src="assets/img/ppl3.jpg" alt="">
                    <div class="caption">
                        <h3>Thumbnail label</h3>
                        <p>Nullam id dolor id nibh ultricies vehicula ut id elit. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus.</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="thumbnail"><img src="assets/img/ppl4.jpg" alt="">
                    <div class="caption">
                        <h3>Thumbnail label</h3>
                        <p>Nullam id dolor id nibh ultricies vehicula ut id elit. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="thumbnail"><img src="assets/img/ppl6.jpg" alt="">
                    <div class="caption">
                        <h3>Thumbnail label</h3>
                        <p>Nullam id dolor id nibh ultricies vehicula ut id elit. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="thumbnail"><img src="assets/img/ppl7.jpg" alt="">
                    <div class="caption">
                        <h3>Thumbnail label</h3>
                        <p>Nullam id dolor id nibh ultricies vehicula ut id elit. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>



    

