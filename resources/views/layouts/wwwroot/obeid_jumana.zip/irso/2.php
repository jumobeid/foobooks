<!DOCTYPE html>
<html>

<head>
      <style>
 body{
    font-family: habibi !important;
}
          h1,h2,h3{
              text-align: center;
          }
    </style>
   <?php include("parts/htmlhead.php"); ?>
</head>

<body id="part2">
   <?php include("parts/nav.php"); ?>
    <div>
     <?php include("about.php"); ?>
    </div>
    <div class="container" id="fcontainer">
            <?php include("parts/footer.php"); ?>
    </div>
    
</body>

</html>