 <div><img class="img-responsive" src="assets/img/lines.png" id="imgline" alt=""></div>
    
  <nav id="navigation" class="navbar navbar-default navbar-fixed-top">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
        <a class="navbar-brand" href="index.php"><img src="assets/img/logo.png" id="logo" alt=""></a>
    </div>
    <div class="collapse navbar-collapse navbar-right" id="myNavbar">
      <ul id="mainnav" class="nav navbar-nav">
        <li id="navpart1"><a href="index.php">Home</a></li>
        <li id="navpart2"><a href="2.php">About</a></li>
        <li><a href="#">Works</a></li>
        <li><a href="#">BuyOnline</a></li>
        <li id="navpart3"><a href="3.php">Contact</a></li>
      </ul>
      
    </div>
  </div>
</nav>
