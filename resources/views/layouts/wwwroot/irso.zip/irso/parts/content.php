       <div class="container" id="top-img">
            <div id="promo">
                <div class="jumbotron">
                    <h1 id="pro">Dubai Downtown </h1>
                    <p>Great investment apportunity&nbsp;</p>
                    <p><a class="btn btn-default" role="button" href="#" id="mainbtn">Learn more</a></p>
                </div>
            </div>
        </div>
  
    <div class="container site_section">
        <h1 class="welcome">VISIONARY ,UNNOVATIVE AND COMMITED TO ADDING SHAREHOLDER VALUE</h1></div>
    <div class="container">
        <div class="darker_section">
            <div class="container site_section">
                <h1 id="welcome">Why choose us?</h1>
                <div id="why" class="row">
                    <div class="col-md-4"><i class="glyphicon glyphicon-user"></i>
                        <h2>Group Structure</h2>
                        <p>Meet our team</p>
                    </div>
                    <div class="col-md-4"><i class="glyphicon glyphicon-stats"></i>
                        <h2>Technical Analysis</h2>
                        <p>Evaluate your investment</p>
                    </div>
                    <div class="col-md-4"><i class="glyphicon glyphicon-th-large"></i>
                        <h2>Projects </h2>
                        <p>Take a tour inside</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container site_section">
        <h1 class="welcome">INSIGHTS REALSTATE SHAPES THE FUTURE THROUGH WORLD-CLASS REAL ESTATE, MALLS, AND HOSPITALITY ASSETS </h1>
        <div class="row">
            <div class="col-md-4">
                <div class="thumbnail">
                    <a href="assets/img/img7.jpg" target="_blank" data-lightbox="works"><img class="img-responsive" src="assets/img/img7.jpg" alt=""></a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="thumbnail">
                    <a href="assets/img/img8.jpg" target="_blank" data-lightbox="works"><img class="img-responsive" src="assets/img/img8.jpg" alt=""></a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="thumbnail">
                    <a href="assets/img/img9.jpg" target="_blank" data-lightbox="works"><img class="img-responsive" src="assets/img/img9.jpg" alt=""></a>
                </div>
            </div>
        </div>
</div>