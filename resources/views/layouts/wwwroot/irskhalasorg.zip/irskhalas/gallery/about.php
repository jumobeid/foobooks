<!DOCTYPE html>
<html>
<head>
	<title>fancyBox - Fancy jQuery Lightbox Alternative | Demonstration</title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootswatch/3.3.7/paper/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Cookie">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <!--<link rel="stylesheet" href="assets/css/styles.min.css"-->
    
    
	
	<!-- Add jQuery library -->
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>

	<!-- Add mousewheel plugin (this is optional) -->
	<!--<script type="text/javascript" src="../lib/jquery.mousewheel-3.0.6.pack.js"></script>-->

	<!-- Add fancyBox main JS and CSS files -->
	<script type="text/javascript" src="../source/jquery.fancybox.js?v=2.1.5"></script>
    <link rel="stylesheet" type="text/css" href="../source/jquery.fancybox.css?v=2.1.5" media="screen" />

	<!-- Add Button helper (this is optional) -->
	<!--<link rel="stylesheet" type="text/css" href="../source/helpers/jquery.fancybox-buttons.css?v=1.0.5" />-->
	<!--<script type="text/javascript" src="../source/helpers/jquery.fancybox-buttons.js?v=1.0.5"></script>-->

	<!-- Add Thumbnail helper (this is optional) -->
	<link rel="stylesheet" type="text/css" href="../source/helpers/jquery.fancybox-thumbs.css?v=1.0.7" />
	<script type="text/javascript" src="../source/helpers/jquery.fancybox-thumbs.js?v=1.0.7"></script>

	<!-- Add Media helper (this is optional) -->
	<!--<script type="text/javascript" src="../source/helpers/jquery.fancybox-media.js?v=1.0.6"></script>-->

	<script type="text/javascript">
		$(document).ready(function() {
			/*
			 *  Simple image gallery. Uses default settings
			 */

			$('.fancybox').fancybox();

			/*
			 *  Different effects
			 */



			/*
			 *  Thumbnail helper. Disable animations, hide close button, arrows and slide to next gallery item if clicked
			*/

			$('.fancybox-thumbs').fancybox({
				prevEffect : 'none',
				nextEffect : 'none',

				closeBtn  : false,
				arrows    : false,
				nextClick : true,

				helpers : {
					thumbs : {
						width  : 50,
						height : 50
					}
				}
			});

			

		});
	</script>
	<style type="text/css">
		.fancybox-custom .fancybox-skin {
			box-shadow: 0 0 50px #222;
		}

		body {
			margin: 0 auto;
			
            text-align: center;
		}
        p{
            text-align: left;
        }
       
       
        
	</style>
</head>
<body>
    <div id="cont"class="container">
        <div class="row">
            <div class="col-md-12">
                <h1 id="inlines">Insights in lines</h1>
                <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum mollis ipsum a leo faucibus ullamcorper. Cras dapibus consequat leo ac condimentum. Maecenas eget semper nisl, eu hendrerit quam. Fusce nec orci vel quam ullamcorper congue.
                    Curabitur tellus dolor, facilisis at turpis a, placerat volutpat enim. Sed dapibus lobortis risus, semper ultrices purus lobortis vitae. Curabitur cursus dui eget velit accumsan, sollicitudin cursus felis mattis. Duis a elit interdum,
                    varius dolor tincidunt, tempus velit. Sed pulvinar, justo tincidunt tempus finibus, leo justo facilisis enim, ac volutpat purus enim eget sapien. Vestibulum interdum, leo accumsan sollicitudin tincidunt, nunc metus euismod felis, nec
                    varius ipsum nibh a tortor. Aliquam erat volutpat. Pellentesque magna dui, varius at purus et, tempus luctus nibh. Sed euismod, leo vitae volutpat vulputate, velit nisi dictum mauris, eu hendrerit arcu ante et sem. In ac turpis libero.
                    Cras euismod metus non lorem porta tincidunt. Aliquam erat volutpat.Sed tincidunt nec diam cursus ullamcorper. Nulla congue hendrerit lacus. In at commodo dolor. Nulla quis nunc a sapien vulputate dignissim. Proin posuere facilisis
                    purus, nec lacinia purus facilisis et. Cras at odio mollis neque pulvinar efficitur eget lobortis tortor. Aenean ullamcorper finibus dui, ac ornare velit condimentum quis. Nulla aliquet, est id varius tempus, neque tellus scelerisque
                    purus, sit amet tristique massa erat vel risus. In placerat vestibulum magna et pulvinar. Nullam tempor dolor ac augue congue accumsan. Cras pulvinar, enim sit amet feugiat vehicula, nibh lectus luctus diam, quis pulvinar est ante
                    non lectus. Vivamus gravida ac purus in vulputate. Mauris tincidunt turpis orci, et dapibus ante pharetra vitae. Integer ullamcorper tempor lacus ac tempus.Aenean id urna facilisis, lobortis metus in, posuere nisi. Nullam porta velit
                    libero, in faucibus metus scelerisque vel. In vel lorem felis. Vestibulum luctus ligula aliquet, venenatis augue eget, accumsan elit. Mauris at nisi lectus. In laoreet dictum commodo.  </p>
	<h1>lorem porta tincidunt. Aliquam erat volutpat.Sed tincidunt nec diam cursus ullamcorper. </h1>
        
   <div class="row">
        <div class="col-md-3">
            <a class="fancybox-thumbs thumbnail" data-fancybox-group="thumb" href="pic1.jpg"><img src="thumb/pic1.jpg" alt="" /></a></div>
        <div class="col-md-3">
            <a class="fancybox-thumbs thumbnail" data-fancybox-group="thumb" href="pic2.jpg"><img src="thumb/pic2.jpg" alt="" /></a></div>
        <div class="col-md-3">
            <a class="fancybox-thumbs thumbnail" data-fancybox-group="thumb" href="pic3.jpg"><img src="thumb/pic3.jpg" alt="" /></a></div>
        
        <div class="col-md-3">
		<a class="fancybox-thumbs thumbnail" data-fancybox-group="thumb" href="pic4.jpg"><img src="thumb/pic4.jpg" alt="" /></a></div>
        </div>
        
	

                   
            </div>
        </div>

    <div id="pics" class="container">
        <div class="row">
            <div class="col-md-12">
                <h1 id="ourteam">Meet our Team</h1></div>
        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="thumbnail"><img src="../assets/img/ppl1.jpg">
                    <div class="caption">
                        <h3>Thumbnail label</h3>
                        <p>Nullam id dolor id nibh ultricies vehicula ut id elit. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="thumbnail"><img src="../assets/img/ppl2.jpg">
                    <div class="caption">
                        <h3>Thumbnail label</h3>
                        <p>Nullam id dolor id nibh ultricies vehicula ut id elit. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="thumbnail"><img src="../assets/img/ppl3.jpg">
                    <div class="caption">
                        <h3>Thumbnail label</h3>
                        <p>Nullam id dolor id nibh ultricies vehicula ut id elit. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus.</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="thumbnail"><img src="../assets/img/ppl4.jpg">
                    <div class="caption">
                        <h3>Thumbnail label</h3>
                        <p>Nullam id dolor id nibh ultricies vehicula ut id elit. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="thumbnail"><img src="../assets/img/ppl6.jpg">
                    <div class="caption">
                        <h3>Thumbnail label</h3>
                        <p>Nullam id dolor id nibh ultricies vehicula ut id elit. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="thumbnail"><img src="../assets/img/ppl7.jpg">
                    <div class="caption">
                        <h3>Thumbnail label</h3>
                        <p>Nullam id dolor id nibh ultricies vehicula ut id elit. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
	

</div>
    
    

</body>
</html>