<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>index.html</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootswatch/3.3.7/paper/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Cookie">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.9.0/css/lightbox.min.css">
    <link rel="stylesheet" href="assets/css/styles.min.css">
     <!-- favicon -->
    <link rel="shortcut icon" href="images/favicon1.ico" type="image/x-icon">
    <link rel="icon" href="assets/img/favicon.ico" type="image/x-icon">
    
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
</head>

<body>
    <div></div><img class="img-responsive" src="assets/img/lines.png" id="imgline">
    <div></div>
    <div></div>
    <nav class="navbar navbar-default navigation-clean" id="navi">
        <div class="container">
            <div class="navbar-header" id="navitems">
                <a class="navbar-brand navbar-link" href="#" id="navig"> <img src="assets/img/logo.png" id="logo"></a>
                <button class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
            </div>
            <div class="collapse navbar-collapse" id="navcol-1">
                <ul class="nav navbar-nav navbar-right">
                    <li class="active" role="presentation"><a href="#">Home </a></li>
                    <li role="presentation"><a href="#">About </a></li>
                    <li role="presentation"><a href="#">Works </a></li>
                    <li role="presentation"><a href="#">Buy Online</a></li>
                    <li role="presentation"><a href="#">Contact </a></li>
                </ul>
            </div>
        </div>
    </nav>
    <div>
        <div class="container" id="top-img">
            <div id="promo">
                <div class="jumbotron">
                    <h1>Dubai Downtown </h1>
                    <p>Great investment apportunity&nbsp;</p>
                    <p><a class="btn btn-default" role="button" href="#" id="mainbtn">Learn more</a></p>
                </div>
            </div>
        </div>
    </div>
    <div class="container site_section">
        <h1 id="welcome">VISIONARY ,UNNOVATIVE AND COMMITED TO ADDING SHAREHOLDER VALUE</h1></div>
    <div class="container">
        <div class="darker_section">
            <div class="container site_section">
                <h1 id="welcome">Why choose us?</h1>
                <div class="row">
                    <div class="col-md-4"><i class="glyphicon glyphicon-user"></i>
                        <h2>Group Structure</h2>
                        <p>Meet our team</p>
                    </div>
                    <div class="col-md-4"><i class="glyphicon glyphicon-stats"></i>
                        <h2>Technical Analysis</h2>
                        <p>Evaluate your investment</p>
                    </div>
                    <div class="col-md-4"><i class="glyphicon glyphicon-th-large"></i>
                        <h2>Projects </h2>
                        <p>Take a tour inside</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container site_section">
        <h1 id="welcome">INSIGHTS REALSTATE SHAPES THE FUTURE THROUGH WORLD-CLASS REAL ESTATE, MALLS, AND HOSPITALITY ASSETS </h1>
        <div class="row">
            <div class="col-md-4">
                <div class="thumbnail">
                    <a href="assets/img/img2.jpg" target="_blank" data-lightbox="works"><img class="img-responsive" src="assets/img/img2.jpg"></a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="thumbnail">
                    <a href="assets/img/img4.jpg" target="_blank" data-lightbox="works"><img class="img-responsive" src="assets/img/img3.jpg"></a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="thumbnail">
                    <a href="assets/img/img3.jpg" target="_blank" data-lightbox="works"><img class="img-responsive" src="assets/img/img4.jpg"></a>
                </div>
            </div>
        </div>
    </div>
    <div class="container" id="fcontainer">
        <footer id="footerimp">
            <div class="row">
                <div class="col-md-4 col-sm-6 footer-navigation">
                    <h3><a href="#" id="footlogo">Insight RealState</a></h3>
                    <p class="links"><a href="#">Home</a><strong> · </strong><a href="#">About </a><strong>  ·</strong><a href="#">Contact</a></p>
                    <p class="company-name">Insiights Co,© 2016</p>
                </div>
                <div class="col-md-4 col-sm-6 footer-contacts">
                    <div><span class="fa fa-map-marker footer-contacts-icon"> </span>
                        <p><span class="new-line-span">21 Revolution Street</span> Dubai, UAE</p>
                    </div>
                    <div><i class="fa fa-phone footer-contacts-icon"></i>
                        <p id="number" class="footer-center-info email text-left"> +971 50 6137078</p>
                    </div>
                    <div><i class="fa fa-envelope footer-contacts-icon"></i>
                        <p id="email">It@insightsrs.com</p>
                    </div>
                </div>
                <div class="clearfix visible-sm-block"></div>
                <div class="col-md-4 footer-about">
                    <h4>About Insights RS</h4>
                    <p> Lorem ipsum dolor sit amet, consectateur adispicing elit. Fusce euismod convallis velit, eu auctor lacus vehicula sit amet.
                    </p>
                    <div class="social-links social-icons"><a href="#"><i class="fa fa-facebook"></i></a><a href="#"><i class="fa fa-twitter"></i></a><a href="#"><i class="fa fa-linkedin"></i></a><a href="#"><i class="fa fa-github"></i></a></div>
                </div>
            </div>
        </footer>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.9.0/js/lightbox-plus-jquery.min.js"></script>
</body>

</html>