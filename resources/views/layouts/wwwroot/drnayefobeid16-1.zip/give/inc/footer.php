    <div id="ana" class="footer-basic">
        <footer>
            <div class="social"><a href="#"><i class="icon ion-social-twitter"></i></a><a href="https://www.facebook.com/profile.php?id=100008387078532&fref=ts"><i class="icon ion-social-facebook"></i></a><a href="https://www.linkedin.com/in/nayef-ali-obeid-a5b46546?authType=NAME_SEARCH&authToken=uv7O&locale=en_US&trk=tyah&trkInfo=clickedVertical%3Amynetwork%2CclickedEntityId%3A162373031%2CauthType%3ANAME_SEARCH%2Cidx%3A1-1-1%2CtarId%3A1483943552862%2Ctas%3Anay"><i class="icon ion-social-linkedin"></i></a></div>
            <p class="copyright">Jumana Obeid © 2017</p>
        </footer>
    </div>
