<head>
<style>
#niv{
text-align:right !important;}

#niv #o1>li>a,#niv #o2>li>a{
text-align:right !important;
font-size:1.3em !important;
color:gray !important;
}

#niv #o1 >li>a:hover,#niv #o2 >li>a:hover{
color:#cdcdcd !important;}
</style>
</head>

    <div id="niv" class="row">
	 <div class="col-sm-3 col-md-6 col-lg-3"></div>
	    <div class="col-sm-3 col-md-6 col-lg-3">
                    <ul id="o1">
                        <li><a href="../lish/1.php"><strong>هتف الشعب ونادى</strong></a></li>
                        <li><a href="../lish/2.php"><strong>غادة العرب</strong></a></li>
                        <li><a href="../lish/3.php" ><strong>أرض الهوى  وأرض البطولة</strong></a></li>
                        
						</ul>
						</div>
		<div class="col-sm-3 col-md-6 col-lg-3">
		<ul id="o2">
		                <li><a href="../lish/4.php"><strong>زمان يمشي على قفاه</strong></a></li>
						<li><a href="../lish/5.php" ><strong>المعلم والتلميذات</strong></a></li>
                        <li><a href="../lish/6.php"><strong>هدية أم</strong></a></li>
                       
						</ul>
                </div>
				 <div class="col-sm-3 col-md-6 col-lg-3"></div>
				</div>