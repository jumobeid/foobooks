              <head>
<style>
#niv2{
text-align:right !important;
list-style:circle !important;}

#niv2 #o1>li>a,#niv2 #o2>li>a{
text-align:right !important;
font-size:1.3em !important;
color:gray !important;
}

#niv2 #o1 >li>a:hover,#niv2 #o2 >li>a:hover{
color:#cdcdcd !important;}
</style>
</head>

    <div id="niv2" class="row">
	 
	    <div class="col-sm-3 col-md-6 col-lg-5">
                    <ul id="o1">
                        <li><a href="http://www.neelwafurat.com/itempage.aspx?id=lbb126072-86200&search=books"><strong> السياسة الخارجية لدولة الإمارات العربية المتحدة </strong></a></li>
                        <li><a href="http://www.neelwafurat.com/itempage.aspx?id=lbb31379-29677&search=books"><strong>مجلس التعاون من التعاون إلى التكامل </strong></a></li>
                        <li><a href="http://www.annahar.com/archive/248402-%D9%86%D8%A7%D9%8A%D9%81-%D8%B9%D9%84%D9%8A-%D8%B9%D8%A8%D9%8A%D8%AF" ><strong>"مجلس التعاون لدول الخليج العربية، من التعاون الى التكامل</strong></a></li>
                        <li><a href="http://www.goodreads.com/author/show/8061477._"><strong>مجلس التعاون لدول الخليج العربية، من التعاون الى التكامل
قراءة ومشاركة
</strong></a></li>
						<li><a href="http://www.albayan.ae/across-the-uae/1998-11-30-1.1029949" ><strong>المحور الثاني: الهيئة الاستشارية للمجلس الاعلى لمجلس التعاون لدول الخليج العربية, ويتضمن ثلاثة فصول, حيث يقدم الدكتور نايف علي عبيد في الفصل الثالث من الكتاب رؤية مستقبلية للهيئة الاستشارية للمجلس الاعلى لمجلس التعاون لدول الخليج العربية</strong></a></li>
                        <li><a href="http://www.alittihad.ae/details.php?id=51646&y=2016"><strong>مركز سلطان بن زايد يبحث التحديات أمام مجلس التعاون</strong></a></li>
                        <li><a href="
http://khmkalnahyan.com/pkg12/index.php?page=show&ex=2&dir=news&lang=1&nid=433&First=&Last=&CurrentPage=&nt=1&src=all&&block_id=407
"><strong>استضاف  الشيخ سلطان بن محمد بن خالد آل نهيان وبحضور الشيخ حمدان بن محمد بن خالد آل نهيان – حفظهما الله - الدكتور نايف علي عبيد</strong></a></li>
                       
						</ul>
						</div>
		<div class="col-sm-3 col-md-6 col-lg-5">
		<ul id="o2">
		                <li><a href="http://www.alarab.co.uk/article/Opinion/96895/%D9%86%D8%A7%D9%8A%D9%81-%D8%B9%D8%A8%D9%8A%D8%AF-%D8%B9%D8%A7%D9%84%D9%85-%D9%82%D8%B6%D9%89-%D8%A3%D8%B1%D8%A8%D8%B9%D9%8A%D9%86-%D8%B9%D8%A7%D9%85%D8%A7-%D9%8A%D8%A8%D8%AD%D8%AB-%D9%81%D9%8A-%D9%85%D8%B3%D8%AA%D9%82%D8%A8%D9%84-%D8%A7%D9%84%D8%AE%D9%84%D9%8A%D8%AC-%D8%A7%D9%84%D8%B9%D8%B1%D8%A8%D9%8A"><strong>ينظم مركز سلطان بن زايد للثقافة والإعلام يوم الثلاثاء 18 أكتوبر الجاري محاضرة للخبير والباحث الاستراتيجي الدكتور نايف علي عبيد بعنوان " " خريطة طريق لمستقبل مجلس التعاون لدول الخليج العربية، وذلك عند الساعة السابعة مساء بمقر المركز في منطقة البطين بأبوظبي .</strong></a></li>
						<li><a href="https://www.almajles.gov.ae:1818/cgi-bin/koha/opac-search.pl?q=ccl=su%3A%7B%20%D8%A7%D9%84%D8%B9%D9%88%D9%84%D9%85%D8%A9%7D&sort_by=relevance_dsc&limit=su-to:%D8%A7%D9%84%D8%B3%D9%8A%D8%A7%D8%B3%D8%A9%20%D8%A7%D9%84%D8%AF%D9%88%D9%84%D9%8A%D8%A9" ><strong>عبيد يؤكد في كتاباته ومحاضراته على أن قيام مجلس التعاون الخليجي في 25 مايو 1981 جاء استجابة طبيعية للإرادة الصادقة لقادة وحكومات وشعوب</strong></a></li>
                        <li><a href="https://www.almajles.gov.ae:1818/cgi-bin/koha/opac-search.pl?q=ccl=su%3A%7B%20%D8%A7%D9%84%D8%B9%D9%88%D9%84%D9%85%D8%A9%7D&sort_by=relevance_dsc&limit=su-to:%D8%A7%D9%84%D8%B3%D9%8A%D8%A7%D8%B3%D8%A9%20%D8%A7%D9%84%D8%AF%D9%88%D9%84%D9%8A%D8%A9"><strong>العولمة مشاهد وتساؤلات</strong></a></li>
                        <li><a href="http://eco.univ-setif.dz/pmb/opac_css/index.php?lvl=notice_display&id=3207"><strong>مجلس التعاون لدول الخليج من التعاون إلى التكامل</strong></a></li>
                        <li><a href="http://www.qau.ye/general-library/page/1883"><strong>المكتبة العامة جامعة الملكة أروى</strong></a></li>
						</ul>
                </div>
				<div class="col-sm-3 col-md-6 col-lg-2"></div>
				</div>