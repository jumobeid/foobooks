   <nav class="navbar navbar-default navigation-clean" id="navigation">
            <div class="container">
                <div class="navbar-header">
                    
                    <button class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
                </div>
                <div class="collapse navbar-collapse" id="navcol-1">
                    <ul id="mainnav" class="nav navbar-nav navbar-right">
                        <li id="navpart5"><a href="5.php">الدراسات</a></li>
                        <li id="navpart4"><a href="4.php">الأشعار</a></li>
                        <li id="navpart3"><a href="3.php">المؤلفات</a></li>
                        <li id="navpart2"><a href="2.php">ألبوم الصور</a></li>
                        <li id="navpart1"><a href="index.php">الشاعر في سطور</a></li>
                    </ul>
                </div>
            </div>
        </nav>