<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Rights of the People of the Five Nations (Constitution of the Iroquois Nations)</title>
    <?php include("inc/htmlhead.php"); ?>
</head>
<body id="part12">
    <?php include("inc/header.php"); ?>
    <?php include("inc/nav.php"); ?>
    <div id="main">
      <?php include("inc/content12.php"); ?>
    </div>
    <?php include("inc/footer.php"); ?>
</body>
</html>
