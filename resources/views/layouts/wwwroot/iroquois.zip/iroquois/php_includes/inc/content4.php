<h3>Names, Duties and Rights of War Chiefs</h3>

<p>36. The title names of the Chief Confederate Lords' War Chiefs shall be:</p>
<ul>
<li>Ayonwaehs, War Chief under Lord Takarihoken (Mohawk)</li>
<li>Kahonwahdironh, War Chief under Lord Odatshedeh (Oneida)</li>
<li>Ayendes, War Chief under Lord Adodarhoh (Onondaga)</li>
<li>Wenenhs, War Chief under Lord Dekaenyonh (Cayuga)</li>
<li>Shoneradowaneh, War Chief under Lord Skanyadariyo (Seneca)</li
</ul>
<p>The women heirs of each head Lord's title shall be the heirs of the War Chief's title of their respective Lord.</p>
<p>The War Chiefs shall be selected from the eligible sons of the female families holding the head Lordship titles.</p>
<p>37. There shall be one War Chief for each Nation and their duties shall be to carry messages for their Lords and to take up the arms of war in case of emergency. They shall not participate in the proceedings of the Confederate Council but shall watch its progress and in case of an erroneous action by a Lord they shall receive the complaints of the people and convey the warnings of the women to him. The people who wish to convey messages to the Lords in the Confederate Council shall do so through the War Chief of their Nation. It shall ever be his duty to lay the cases, questions and propositions of the people before the Confederate Council.</p>
<p>38. When a War Chief dies another shall be installed by the same rite as that by which a Lord is installed.</p>
<p>39. If a War Chief acts contrary to instructions or against the provisions of the Laws of the Great Peace, doing so in the capacity of his office, he shall be deposed by his women relatives and by his men relatives. Either the women or the men alone or jointly may act in such a case. The women title holders shall then choose another candidate.</p>
<p>40. When the Lords of the Confederacy take occasion to dispatch a messenger in behalf of the Confederate Council, they shall wrap up any matter they may send and instruct the messenger to remember his errand, to turn not aside but to proceed faithfully to his destination and deliver his message according to every instruction.</p>
<p>41. If a message borne by a runner is the warning of an invasion he shall whoop, "Kwa-ah, Kwa-ah," twice and repeat at short intervals; then again at a longer interval.</p>
<p>If a human being is found dead, the finder shall not touch the body but return home immediately shouting at short intervals, "Koo-weh!"</p>
