<div id="navigation">
<ul id="mainnav">
<li id="navpart1"><a href="1.php">The Great Binding Law, Gayanashagowa</a></li>
<li id="navpart2"><a href="2.php">Rights, Duties and Qualifications of Lords</a></li>
<li id="navpart3"><a href="3.php">Election of Pine Tree Chiefs</a></li>
<li id="navpart4"><a href="4.php">Names, Duties and Rights of War Chiefs</a></li>
<li id="navpart5"><a href="5.php">Clans and Consanguinity</a></li>
<li id="navpart6"><a href="6.php">Official Symbolism</a></li>
<li id="navpart7"><a href="7.php">Laws of Adoption</a></li>
<li id="navpart8"><a href="8.php">Laws of Emigration</a></li>
<li id="navpart9"><a href="9.php">Rights of Foreign Nations</a></li>
<li id="navpart10"><a href="10.php">Rights and Powers of War</a></li>
<li id="navpart11"><a href="11.php">Treason or Secession of a Nation</a></li>
<li id="navpart12"><a href="12.php">Rights of the People of the Five Nations</a></li>
<li id="navpart13"><a href="13.php">Religious Ceremonies Protected</a></li>
<li id="navpart14"><a href="14.php">The Installation Song</a></li>
<li id="navpart15"><a href="15.php">Protection of the House</a></li>
<li id="navpart16"><a href="16.php">Funeral Addresses</a></li>
</ul>
</div>
