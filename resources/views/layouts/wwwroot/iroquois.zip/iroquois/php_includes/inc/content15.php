
<h3>Protection of the House</h3>

<p>107. A certain sign shall be known to all the people of the Five Nations which shall denote that the owner or occupant of a house is absent. A stick or pole in a slanting or leaning position shall indicate this and be the sign. Every person not entitled to enter the house by right of living within it upon seeing such a sign shall not approach the house either by day or by night but shall keep as far away as his business will permit.</p>
