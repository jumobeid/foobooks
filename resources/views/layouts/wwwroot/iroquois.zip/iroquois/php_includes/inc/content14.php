
<h3>The Installation Song</h3>

<p>105. The song used in installing the new Lord of the Confederacy shall be sung by Adodarhoh and it shall be:</p>
<pre>
"Haii, haii Agwah wi-yoh
   "     "  A-kon-he-watha
   "     "  Ska-we-ye-se-go-wah
   "     "  Yon-gwa-wih
   "     "  Ya-kon-he-wa-tha
</pre>
<pre>
 Haii, haii It is good indeed
   "     "  (That) a broom, -
   "     "  A great wing,
   "     "  It is given me
   "     "  For a sweeping instrument."
</pre>
<p>106. Whenever a person properly entitled desires to learn the Pacification Song he is privileged to do so but he must prepare a feast at which his teachers may sit with him and sing. The feast is provided that no misfortune may befall them for singing the song on an occasion when no chief is installed.</p>
