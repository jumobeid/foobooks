
<h3>Religious Ceremonies Protected</h3>

<p>99. The rites and festivals of each nation shall remain undisturbed and shall continue as before because they were given by the people of old times as useful and necessary for the good of men.</p>
<p>100. It shall be the duty of the Lords of each brotherhood to confer at the approach of the time of the Midwinter Thanksgiving and to notify their people of the approaching festival. They shall hold a council over the matter and arrange its details and begin the Thanksgiving five days after the moon of Dis-ko-nah is new. The people shall assemble at the appointed place and the nephews shall notify the people of the time and place. From the beginning to the end the Lords shall preside over the Thanksgiving and address the people from time to time.</p>
<p>101. It shall be the duty of the appointed managers of the Thanksgiving festivals to do all that is needed for carrying out the duties of the occasions.</p>
<p>The recognized festivals of Thanksgiving shall be the Midwinter Thanksgiving, the Maple or Sugar-making Thanksgiving, the Raspberry Thanksgiving, the Strawberry Thanksgiving, the Cornplanting Thanksgiving, the Corn Hoeing Thanksgiving, the Little Festival of Green Corn, the Great Festival of Ripe Corn and the complete Thanksgiving for the Harvest.</p>
<p>Each nation's festivals shall be held in their Long Houses.</p>
<p>102. When the Thansgiving for the Green Corn comes the special managers, both the men and women, shall give it careful attention and do their duties properly.</p>
<p>103. When the Ripe Corn Thanksgiving is celebrated the Lords of the Nation must give it the same attention as they give to the Midwinter Thanksgiving.</p>
<p>104. Whenever any man proves himself by his good life and his knowledge of good things, naturally fitted as a teacher of good things, he shall be recognized by the Lords as a teacher of peace and religion and the people shall hear him.</p>
