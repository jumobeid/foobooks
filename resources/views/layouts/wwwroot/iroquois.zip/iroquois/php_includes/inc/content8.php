
<h3>Laws of Emigration</h3>

<p>71. When any person or family belonging to the Five Nations desires to abandon their birth nation and the territory of the Five Nations, they shall inform the Lords of their nation and the Confederate Council of the Five Nations shall take cognizance of it.</p>
<p>72. When any person or any of the people of the Five Nations emigrate and reside in a region distant from the territory of the Five Nations Confederacy, the Lords of the Five Nations at will may send a messenger carrying a broad belt of black shells and when the messenger arrives he shall call the people together or address them personally displaying the belt of shells and they shall know that this is an order for them to return to their original homes and to their council fires.</p>
