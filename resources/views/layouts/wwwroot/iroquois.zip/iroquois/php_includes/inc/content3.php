
<h3>Election of Pine Tree Chiefs</h3>

<p>35. Should any man of the Nation assist with special ability or show great interest in the affairs of the Nation, if he proves himself wise, honest and worthy of confidence, the Confederate Lords may elect him to a seat with them and he may sit in the Confederate Council. He shall be proclaimed a 'Pine Tree sprung up for the Nation' and shall be installed as such at the next assembly for the installation of Lords. Should he ever do anything contrary to the rules of the Great Peace, he may not be deposed from office - no one shall cut him down - but thereafter everyone shall be deaf to his voice and his advice. Should he resign his seat and title no one shall prevent him. A Pine Tree chief has no authority to name a successor nor is his title hereditary.</p>

