
<h3>Treason or Secession of a Nation</h3>

<p>92. If a nation, part of a nation, or more than one nation within the Five Nations should in any way endeavor to destroy the Great Peace by neglect or violating its laws and resolve to dissolve the Confederacy, such a nation or such nations shall be deemed guilty of treason and called enemies of the Confederacy and the Great Peace.</p>
<p>It shall then be the duty of the Lords of the Confederacy who remain faithful to resolve to warn the offending people. They shall be warned once and if a second warning is necessary they shall be driven from the territory of the Confederacy by the War Chiefs and his men.</p>
