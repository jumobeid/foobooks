<!DOCTYPE html>
<html>
<head>
	
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

	<!-- Add jQuery library -->
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>

	<!-- Add mousewheel plugin (this is optional) -->
	<!--<script type="text/javascript" src="../lib/jquery.mousewheel-3.0.6.pack.js"></script>-->

	<!-- Add fancyBox main JS and CSS files -->
	<script type="text/javascript" src="jquery.fancybox.js?v=2.1.5"></script>
    <link rel="stylesheet" type="text/css" href="jquery.fancybox.css?v=2.1.5" media="screen" />

	<!-- Add Button helper (this is optional) -->
	<!--<link rel="stylesheet" type="text/css" href="../source/helpers/jquery.fancybox-buttons.css?v=1.0.5" />-->
	<!--<script type="text/javascript" src="../source/helpers/jquery.fancybox-buttons.js?v=1.0.5"></script>-->

	<!-- Add Thumbnail helper (this is optional) -->
	<link rel="stylesheet" type="text/css" href="helpers/jquery.fancybox-thumbs.css?v=1.0.7" />
	<script type="text/javascript" src="helpers/jquery.fancybox-thumbs.js?v=1.0.7"></script>

	<!-- Add Media helper (this is optional) -->
	<!--<script type="text/javascript" src="../source/helpers/jquery.fancybox-media.js?v=1.0.6"></script>-->

	<script type="text/javascript">
		$(document).ready(function() {
			/*
			 *  Simple image gallery. Uses default settings
			 */

			$('.fancybox').fancybox();

			/*
			 *  Different effects
			 */



			/*
			 *  Thumbnail helper. Disable animations, hide close button, arrows and slide to next gallery item if clicked
			*/

			$('.fancybox-thumbs').fancybox({
				prevEffect : 'none',
				nextEffect : 'none',

				closeBtn  : false,
				arrows    : false,
				nextClick : true,

				helpers : {
					thumbs : {
						width  : 50,
						height : 50
					}
				}
			});

			

		});
	</script>
	<style type="text/css">
		.fancybox-custom .fancybox-skin {
			box-shadow: 0 0 50px #222;
		}

		body {
			max-width: 950px;
			margin: 0 auto;
            text-align: center;
		}
        
	</style>
</head>
<body>

	<p>
		<a class="fancybox-thumbs" data-fancybox-group="thumb" href="gnp01.jpg"><img class="sora" src="thumb/gnp01.jpg" alt="" /></a>

		

		<a class="fancybox-thumbs" data-fancybox-group="thumb" href="gnp03.jpg"><img class="sora" src="thumb/gnp03.jpg" alt="" /></a>
        <br/>

		<a class="fancybox-thumbs" data-fancybox-group="thumb" href="gnp04.jpg"><img class="sora" src="thumb/gnp04.jpg" alt="" /></a>
        <a class="fancybox-thumbs" data-fancybox-group="thumb" href="gnp05.jpg"><img class="sora" src="thumb/gnp05.jpg" alt="" /></a>
        <a class="fancybox-thumbs" data-fancybox-group="thumb" href="gnp06.jpg"><img class="sora"  src="thumb/gnp06.jpg" alt="" /></a>
        
        <br/>
        <a class="fancybox-thumbs" data-fancybox-group="thumb" href="gnp07.jpg"><img class="sora" src="thumb/gnp07.jpg" alt="" /></a>
        <a class="fancybox-thumbs" data-fancybox-group="thumb" href="gnp08.jpg"><img class="sora" src="thumb/gnp08.jpg" alt="" /></a>
        <a class="fancybox-thumbs" data-fancybox-group="thumb" href="gnp09.jpg"><img class="sora" src="thumb/gnp09.jpg" alt="" /></a>
         <a class="fancybox-thumbs" data-fancybox-group="thumb" href="gnp10.jpg"><img class="sora" src="thumb/gnp10.jpg" alt="" /></a>
	</p>

   


	

</body>
</html>