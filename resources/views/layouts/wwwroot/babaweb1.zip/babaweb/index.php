<!DOCTYPE html>
<html>

<head>
 <?php include("inc/htmlhead.php"); ?> 
</head>
<header>
    <?php include("inc/header.php"); ?> 
    </header>
<body>
  <div class="row">
            <div  class="col-md-12">
                <div class="col-md-4"></div>
                <div  class="col-md-8">
                <?php include("inc/nav.php"); ?> 
                </div>
      </div>
    </div>
        <div class="row">
          
            
     <div id="main">
            
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
            <script src="assets/js/main.js"></script>
            
            </div>
        </div>
    
    <div  class="footer-clean">
     <?php include("inc/footer.php"); ?>
    </div>
  
</body>

</html>
