
      
                
                    <nav>
                        
                                <a href="maincont" class="active">الشاعر في سطور</a>
                                <a href="2">ألبوم الصور</a>
                                <a href="3">الأشعار</a>
                                <a href="4">المؤلفات </a>
                               
                           
                     </nav>
                        
                  
     
          
            
