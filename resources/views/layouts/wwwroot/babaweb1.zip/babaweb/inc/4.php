<!DOCTYPE html>
<html>

<head>
 <?php include("inc/htmlhead.php"); ?> 
</head>
<header>
    <?php include("inc/header.php"); ?> 
</header>
<body id="part4">
  <div id="navigation" class="row">
            <div  class="col-md-12">
                <div class="col-md-4"></div>
                <div  class="col-md-8">
                <?php include("inc/mainnav.php"); ?> 
                </div>
      </div>
    </div>
        <div class="row">
          
             <?php include("inc/writing.php"); ?></div>
    
    
    <div  class="footer-clean">
     <?php include("inc/footer.php"); ?>
    </div>
  
</body>

</html>
