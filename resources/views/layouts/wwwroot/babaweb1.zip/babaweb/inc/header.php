   <div id="bg1"> </div>
<!--<img src="background.gif" alt="" >-->