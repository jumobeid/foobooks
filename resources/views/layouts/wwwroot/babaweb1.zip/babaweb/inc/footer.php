   <footer>
            <div class="container">
                <div id="bots" class="row">
                    <div class="col-md-3 col-sm-4 item">
                       
                     
                    </div>
                    <div class="col-md-3 col-sm-4 item">
                    
                       
                    </div>
                    <div class="col-md-3 col-sm-4 item">
                     <p class="copyright">Jumana Obeid © 2016</p>   
                       
                    </div>
                    <div id="down" class="col-md-3">
                        <a href="https://www.facebook.com/profile.php?id=100008387078532&fref=ts">
                        <i class="fa fa-facebook-square" style="font-size:48px";></i></a>
                        
                        <a href="#"><i class=" fa fa-twitter-square"style="font-size:48px";></i></a>
                        
                        <a href="https://www.linkedin.com/in/nayef-ali-obeid-a5b46546?authType=NAME_SEARCH&authToken=uv7O&locale=en_US&trk=tyah&trkInfo=clickedVertical%3Amynetwork%2CclickedEntityId%3A162373031%2CauthType%3ANAME_SEARCH%2Cidx%3A1-1-1%2CtarId%3A1482229753861%2Ctas%3Anayef%20o">
                        <i class="fa fa-linkedin-square" style="font-size:48px";></i></a>
                        
                    </div>
                </div>
            </div>
        </footer>
