$(document).ready(function(){
    
    //initial page
    $('#main').load('inc/maincont.php');
   
    //handle the clicks
    $('nav > a').click(function(){
     
    //change the i'm here id to the page clicked
   
        
     var page=$(this).attr('href');
      
     if(page=="2"){
        // code to be executed if clicked on a page
    $('#main').load('gallery.php');
        }else{
     $('#main').load('inc/'+page+'.php');
    }
    $(this).addClass("active").siblings().removeClass("active");
                     
     return false;                    
   });
  
 });
  

   
   
     